#include "JYJ.h"

JYJ::JYJ(const std::string& name, const int stat[])
    : Player(name, stat)
{
    job = "JYJ";
}