#include "Warrior.h"
#include <string>
#include <iostream>

Warrior::Warrior(std::string name, int hp, int mp, int power, int defence)
    : Player(name, hp, mp, power, defence)
{
    job = "����";
    this->defence += 30;
}

void Warrior::attack()
{
    std::cout << name << "��(��) ���� �ֵθ���!" << std::endl;
}