#include "AlchemyWorkshop.h"
#include <iostream>

using namespace std;

AlchemyWorkshop::AlchemyWorkshop()
{
    PotionRecipe hpPotion;

    hpPotion.potionName = "HP����";
    hpPotion.ingredient1Name = "���";
    hpPotion.ingredient1Count = 1;
    hpPotion.ingredient2Name = "������";
    hpPotion.ingredient2Count = 1;

    recipes.push_back(hpPotion);

    PotionRecipe staminaPotion;

    staminaPotion.potionName = "���¹̳�����";
    staminaPotion.ingredient1Name = "���";
    staminaPotion.ingredient1Count = 1;
    staminaPotion.ingredient2Name = "����";
    staminaPotion.ingredient2Count = 1;

    recipes.push_back(staminaPotion);

    ingredients["���"] = 3;
    ingredients["������"] = 2;
    ingredients["����"] = 1;
}

void AlchemyWorkshop::PrintAllRecipes() const
{
    for (const PotionRecipe& recipe : recipes)
    {
        recipe.PrintInfo();
    }
}

void AlchemyWorkshop::FindRecipeByPotionName(const string& potionName) const
{
    bool found = false;

    for (const PotionRecipe& recipe : recipes)
    {
        if (recipe.potionName == potionName)
        {
            recipe.PrintInfo();
            found = true;
        }
    }

    if (found == false)
    {
        cout << "�ش� ���� �����Ǹ� ã�� �� �����ϴ�." << endl;
    }
}

void AlchemyWorkshop::FindRecipesByIngredientName(const string& ingredientName) const
{
    bool found = false;

    for (const PotionRecipe& recipe : recipes)
    {
        if (recipe.ingredient1Name == ingredientName || recipe.ingredient2Name == ingredientName)
        {
            recipe.PrintInfo();
            found = true;
        }
    }

    if (found == false)
    {
        cout << "�ش� ��ᰡ �� ���� �����Ǹ� ã�� �� �����ϴ�." << endl;
    }
}
 
bool AlchemyWorkshop::CraftPotion(const std::string& potionName)
{
    for (const PotionRecipe& recipe : recipes)
    {
        if (recipe.potionName == potionName)
        {
            if (ingredients[recipe.ingredient1Name] < recipe.ingredient1Count ||
                ingredients[recipe.ingredient2Name] < recipe.ingredient2Count)
            {
                cout << "��ᰡ �����մϴ�." << endl;
                return false;
            }

            ingredients[recipe.ingredient1Name] -= recipe.ingredient1Count;
            ingredients[recipe.ingredient2Name] -= recipe.ingredient2Count;

            cout << potionName << " ���� ����!" << endl;
            return true;
        }
    }

    cout << "�ش� ���� �����Ǹ� ã�� �� �����ϴ�." << endl;
    return false;
}