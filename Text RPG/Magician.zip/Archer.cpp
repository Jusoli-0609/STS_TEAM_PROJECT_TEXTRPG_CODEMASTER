#include "Archer.h"
#include <string>
#include <iostream>

Archer::Archer(std::string name, int hp, int mp, int power, int defence)
    : Player(name, hp, mp, power, defence)
{
    job = "�ü�";
    this->hp += 30;
}

void Archer::attack()
{
    std::cout << name << "��(��) ȭ���� �߻��Ѵ�!" << std::endl;
}