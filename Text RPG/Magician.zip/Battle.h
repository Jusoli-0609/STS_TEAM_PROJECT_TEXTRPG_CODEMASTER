#pragma once

#include "Player.h"
#include "Monster.h"
#include "Inventory.h"

// =======================
// ���� �޴�
// =======================

enum Battle_Menu
{
    ATTACK = 1,
    SKILL,
    ITEM
};

// =======================
// ���� ����
// =======================

void Battle(Player* player, Monster& monster, Inventory& inventory);

// =======================
// UI (UI ���)
// =======================

void Show_Battle_Start(Player* player, Monster& monster);

void Show_Battle_Status(Player* player, Monster& monster);

void Show_Battle_Menu();

void Show_Battle_End(Player* player, Monster& monster);

// =======================
// �÷��̾� ��
// =======================

void Player_Turn(Player* player, Monster& monster, Inventory& inventory);

void Attack(Player* player, Monster& monster);

void Skill(Player* player, Monster& monster);

void Item(Player* player, Inventory& inventory);

// =======================
// ���� ��
// =======================

void Monster_Turn(Player* player, Monster& monster);

void Monster_Attack(Player* player, Monster& monster);

void Monster_Skill(Player* player, Monster& monster);

// =======================
// ���� ����
// =======================

bool Check_Battle_End(Player* player, Monster& monster, Inventory& inventory);