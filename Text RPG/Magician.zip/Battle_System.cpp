#include "Battle_System.h"
#include <iostream>

using namespace std;

//======================================================
// ���� ����
//======================================================

void Battle(Player* player, Monster& monster, Inventory& inventory)
{

    if (player == nullptr)
    {
        return;
    }

    Show_Battle_Start(player, monster);

    while (true)
    {
        Show_Battle_Status(player, monster);

        Player_Turn(player, monster, inventory);

        if (Check_Battle_End(player, monster, inventory))
        {
            break;
        }

        Monster_Turn(player, monster);

        if (Check_Battle_End(player, monster, inventory))
        {
            break;
        }
    }

    Show_Battle_End(player, monster);
}

//======================================================
// UI (UI ���)
//======================================================

void Show_Battle_Start(Player* player, Monster& monster)
{
    // UI ���� ����
}

void Show_Battle_Status(Player* player, Monster& monster)
{
    // UI ���� ���
}

void Show_Battle_Menu()
{
    // UI ������

    cout << endl;
    cout << "==============================" << endl;
    cout << "        �÷��̾� ��" << endl;
    cout << "==============================" << endl;
    cout << "1. ����" << endl;
    cout << "2. ��ų" << endl;
    cout << "3. ������" << endl;
    cout << "==============================" << endl;
    cout << "���� : ";
}

void Show_Battle_End(Player* player, Monster& monster)
{
    // UI ���� ����
}

//======================================================
// �÷��̾� ��
//======================================================

void Player_Turn(Player* player, Monster& monster, Inventory& inventory)
{
    //�÷��̾� ���� (JRPG �� ����)

    int menu;

    Show_Battle_Menu();

    cin >> menu;

    switch (menu)
    {
    case ATTACK:
    {
        Attack(player, monster);
        break;
    }

    case SKILL:
    {
        Skill(player, monster);
        break;
    }

    case ITEM:
    {
        Item(player, inventory);
        break;
    }



    default:
    {
        cout << "�߸��� �Է��Դϴ�." << endl;
        break;
    }
    }
}

void Item(Player* player, Inventory& inventory)
{
    // �κ��丮 ������

    cout << "������ ��� �غ� ���Դϴ�." << endl;
}

//======================================================
// �÷��̾� ����
//======================================================

void Attack(Player* player, Monster& monster)
{

    int Before_Monster_HP = monster.getHP();

    int Damage = player->getPower() - monster.getDefence();

    if (Damage < 1)
    {
        Damage = 1;
    }

    monster.setHP(Before_Monster_HP - Damage);

    cout << endl;
    cout << "����!" << endl;

    cout << monster.getName()
        << "���� "
        << Damage
        << " ������!" << endl;

    cout << monster.getName()
        << " HP : "
        << Before_Monster_HP
        << " -> "
        << monster.getHP()
        << endl;
}

//======================================================
// �÷��̾� ��ų
//======================================================

void Skill(Player* player, Monster& monster)
{
    // ���� ��ų
}

//======================================================
// ���� ��
//======================================================

void Monster_Turn(Player* player, Monster& monster)
{
    // ���� ����

    cout << endl;
    cout << "------ ���� �� ------" << endl;

    // TODO : ���� �ൿ ����
    Monster_Attack(player, monster);


}

//======================================================
// ���� ����
//======================================================

void Monster_Attack(Player* player, Monster& monster)
{
    int Before_Player_HP = player->getHp();

    int Damage = monster.getPower() - player->getDefence();

    if (Damage < 1)
    {
        Damage = 1;
    }

    player->setHp(Before_Player_HP - Damage);

    cout << monster.getName()
        << "�� ����!" << endl;

    cout << "�÷��̾� HP : "
        << Before_Player_HP
        << " -> "
        << player->getHp()
        << endl;
}


//======================================================
// ���� ��ų
//======================================================

void Monster_Skill(Player* player, Monster& monster)
{
    // TODO : ���� ���

    cout << monster.getName()
        << "��(��) Ư�� ��ų�� ����ߴ�!" << endl;
}

//======================================================
// ���� ����
//======================================================

bool Check_Battle_End(Player* player, Monster& monster, Inventory& inventory)
{
    if (monster.getHP() <= 0)
    {
        cout << endl;
        cout << "���� �¸�!" << endl;
        cout << monster.getDropItemName() << " ȹ��!" << endl;

        return true;
    }

    if (player->getHp() <= 0)
    {
        cout << endl;
        cout << "���� �й�!" << endl;

        return true;
    }

    return false;
}